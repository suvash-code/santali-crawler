import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
import datetime

def is_ol_chiki(text):
    return bool(re.search(r'[\u1C50-\u1C7F]', text))

def is_santali(text):
    if is_ol_chiki(text):
        return True
    santali_keywords = [
        'santali', 'santhal',
        'ᱥᱟᱱᱛᱟᱞᱤ', 'ᱡᱚᱛᱚ',
        'ol chiki'
    ]
    return any(keyword.lower() in text.lower() for keyword in santali_keywords)

def crawl_santali_pages(urls):
    records = []
    for url in urls:
        try:
            response = requests.get(url, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            paragraphs = soup.find_all('p')
            for para in paragraphs:
                text = para.get_text().strip()
                if text and is_santali(text):
                    records.append({
                        'url': url,
                        'text': text,
                        'is_ol_chiki': is_ol_chiki(text)
                    })
            print(f"✅ {url} → {len(records)} records so far")
        except Exception as e:
            print(f"❌ Error crawling {url}: {e}")
    return pd.DataFrame(records)

if __name__ == "__main__":
    urls = [
        "https://santali.wikipedia.org/wiki/%E1%B1%A5%E1%B1%9F%E1%B1%B1%E1%B1%9B%E1%B1%9F%E1%B1%9E%E1%B1%A4",
        "https://www.jharkhandmirror.net/category/santali/"
    ]

    df = crawl_santali_pages(urls)

    if not df.empty:
        filename = f"santali_data_{datetime.date.today()}.csv"
        df.to_csv(filename, index=False)
        print(f"\n💾 Saved {len(df)} rows to {filename}")
    else:
        print("\n⚠️ No Santali content found.")
