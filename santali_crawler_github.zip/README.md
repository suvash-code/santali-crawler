# 🌐 Santali Crawler (GitHub + Hugging Face)

This project crawls Santali (Ol Chiki + Latin) data daily and uploads it to Hugging Face Datasets.

## 🚀 Setup

1. Fork this repo to your GitHub.
2. Go to **Settings > Secrets and variables > Actions > New repository secret**  
   Add:
   - `HF_TOKEN` = Your Hugging Face token
3. Hugging Face dataset must exist before first run:
   ```bash
   huggingface-cli repo create santali-crawl-data --type dataset
   ```
4. GitHub Actions will auto-run daily.

## 📂 Output
Crawled text files will be uploaded to:
👉 https://huggingface.co/datasets/Murmu722/santali-crawl-data
