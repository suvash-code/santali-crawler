import os
import requests
from bs4 import BeautifulSoup
from huggingface_hub import HfApi, HfFolder
import datetime

HF_TOKEN = os.getenv("HF_TOKEN")
DATASET_REPO = "Murmu722/santali-crawl-data"

def crawl_page(url):
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")
        words = [w.get_text(strip=True) for w in soup.select("a")]
        return words
    except Exception as e:
        print(f"❌ Error crawling {url}: {e}")
        return []

def save_and_upload(data, filename):
    os.makedirs("data", exist_ok=True)
    filepath = os.path.join("data", filename)
    with open(filepath, "w", encoding="utf-8") as f:
        for item in data:
            f.write(item + "\n")

    api = HfApi()
    api.upload_file(
        path_or_fileobj=filepath,
        path_in_repo=filename,
        repo_id=DATASET_REPO,
        repo_type="dataset",
        token=HF_TOKEN,
    )
    print(f"✅ Uploaded {filename} to {DATASET_REPO}")

if __name__ == "__main__":
    urls = [
        "https://talkingdictionary.swarthmore.edu/santali/?initial=a&page=1",
        "https://talkingdictionary.swarthmore.edu/santali/?initial=b&page=1",
    ]

    all_data = []
    for url in urls:
        data = crawl_page(url)
        print(f"✅ Crawled {len(data)} items from {url}")
        all_data.extend(data)

    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    save_and_upload(all_data, f"santali_crawl_{timestamp}.txt")
